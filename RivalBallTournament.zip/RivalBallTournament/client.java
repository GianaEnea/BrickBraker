public class client {
    public static void main(String[] args) {
        
    }
}
