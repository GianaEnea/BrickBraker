public class server {
    public static void main(String[] args) {
        
    }
}
